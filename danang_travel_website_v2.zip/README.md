# DANANG 2026 여행 웹사이트

## 업로드 방법
1. GitHub `Travel` 저장소로 이동
2. 기존 `index.html`이 있으면 삭제하거나 덮어쓰기
3. 이 ZIP을 풀고 `index.html` 업로드
4. Commit changes
5. Settings → Pages → Deploy from a branch → main / root

접속 주소:
https://wnsud735-coder.github.io/Travel/
